export const environment = {
    production: true,
    baseUrl:"https://lecture-lab-fu6q.onrender.com"
      // baseUrl:"http://172.16.16.4:3002"
    //  baseUrl:"http://192.168.100.45:3001"
    
};
