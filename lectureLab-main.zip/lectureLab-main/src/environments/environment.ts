export const environment = {
    production: false,
    // baseUrl:"http://192.168.100.45:3000"
    baseUrl:"https://lecture-lab-fu6q.onrender.com"
    //   baseUrl:"http://172.16.16.4:3002"
};
    